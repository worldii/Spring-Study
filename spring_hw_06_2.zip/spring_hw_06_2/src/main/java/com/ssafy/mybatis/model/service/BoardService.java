package com.ssafy.mybatis.model.service;

public interface BoardService {

}
