package com.ssafy.mybatis.model.service;

import com.ssafy.mybatis.model.dto.Member;

public interface MemberService {
    int joinMember(Member member);
}
